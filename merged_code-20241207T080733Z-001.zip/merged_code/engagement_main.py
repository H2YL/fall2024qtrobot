#!/usr/bin/env python3
# main.py

import rospy
import time
from std_msgs.msg import Float32, String, Bool
from pomodoro_timer import PomodoroTimer
from prompt import start_conversation, post_pomodoro_conversation
import threading
import subprocess
import os
import signal
import logging
import fcntl
LOCK_FILE = "/tmp/conversation.lock"
if os.path.exists(LOCK_FILE):
    os.remove(LOCK_FILE)
    
# def acquire_lock():
#     if os.path.exists(LOCK_FILE):
#         return False
#     with open(LOCK_FILE, "w") as f:
#         f.write("locked by engagement detection.\n")
#     return True

# def release_lock():
#     if os.path.exists(LOCK_FILE):
#         os.remove(LOCK_FILE)

# def release_lock_with_delay(delay_seconds):
#     def delay_release():
#         with open(LOCK_FILE, "a") as f:
#             f.write("Releasing lock in 2 minutes.")
#         time.sleep(delay_seconds)
#         release_lock()
#         print("Lock released.")
#     threading.Thread(target=delay_release, daemon=True).start()


# Try to acquire the lock
def acquire_lock():
    try:
        if os.path.exists(LOCK_FILE):
            return False
        
        lock_file = open(LOCK_FILE, "w+")
        # Try to acquire an exclusive lock (non-blocking)
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_file.write("locked by engagement detection.\n")
        lock_file.flush()
        lock_file.close()
        # If successful, return the lock file object for future use
        return True
    except IOError:
        # If the lock is already held, return None
        return False
    except:
        print(f"An error occurred: {e}")
        return False

# Release the lock
def release_lock():
    try:
        lock_file = open(LOCK_FILE, "r+")
       
        fcntl.flock(lock_file, fcntl.LOCK_UN)  # Unlock the file
        lock_file.close()  # Close the lock file
        print("Lock released.")
        os.remove(LOCK_FILE)
    except Exception as e:
        print(f"Error releasing lock: {e}")

# Release the lock with a delay in a separate thread
def release_lock_with_delay(delay_seconds):
    def delay_release():
        lock_file = open(LOCK_FILE, "a")
        lock_file.write("Releasing engagement lock in 2 minutes.\n")
        lock_file.flush()
        lock_file.close()
        time.sleep(delay_seconds)
        release_lock()
    
    threading.Thread(target=delay_release, daemon=True).start()
    
class MainApp:
    def __init__(self):
        self.engagement_levels = []
        self.engagement_sub = rospy.Subscriber('/engagement_level', Float32, self.engagement_callback)
        self.pomodoro_timer = PomodoroTimer()
        self.distraction_tasks = []
        self.engagement_monitoring = False
        self.engagement_timer = None
        self.is_conversation_active = False
        self.last_conversation_time = None
        self.cooldown_period = 120  # Cooldown period in seconds
        self.conversation_requested = False
        self.display_engagement_pub = rospy.Publisher('/display_engagement', Bool, queue_size=10)
        self.pomodoro_state = 'stopped'
        self.pomodoro_state_sub = rospy.Subscriber('/pomodoro_state', String, self.pomodoro_state_callback)
        self.engagement_detector_process = None
        self.is_shutting_down = False  # Added flag to track shutdown state
        self.engagement_detector_started = False  # Added flag to track engagement detector status
        signal.signal(signal.SIGINT, self.shutdown)

    def shutdown(self, signum, frame):
        rospy.loginfo("Shutting down MainApp...")
        self.is_shutting_down = True  # Set shutdown flag
        self.stop_engagement_monitoring()
        self.pomodoro_timer.stop_pomodoro()
        self.stop_engagement_detector()
        self.stop_website_blocker()  # Ensure websites are unblocked
        self.engagement_sub.unregister()
        rospy.signal_shutdown("User requested shutdown.")

    def engagement_callback(self, msg):
        if not self.engagement_detector_started:
            self.engagement_detector_started = True  # Set flag when first message is received
            rospy.loginfo("Engagement detector has started publishing.")
            self.pomodoro_timer.start_pomodoro()
        if self.engagement_monitoring:
            self.engagement_levels.append((rospy.get_time(), msg.data))
            if not self.is_conversation_active:
                rospy.loginfo(f"Received engagement level: {msg.data}")

    def start_engagement_monitoring(self):
        self.engagement_levels = []
        self.engagement_monitoring = True
        self.engagement_timer = rospy.Timer(rospy.Duration(30), self.check_engagement)  # Changed to 30 seconds

    def stop_engagement_monitoring(self):
        self.engagement_monitoring = False
        if self.engagement_timer:
            self.engagement_timer.shutdown()
            self.engagement_timer = None

    def pomodoro_state_callback(self, msg):
        if self.is_shutting_down:
            return  # Do nothing if shutting down
        self.pomodoro_state = msg.data
        if self.pomodoro_state == 'work':
            self.start_engagement_monitoring()
            self.display_engagement_pub.publish(Bool(True))  # Show engagement levels
            self.resume_engagement_detector()
            self.start_website_blocker()  # Block websites during work state
        elif self.pomodoro_state == 'break':
            self.stop_engagement_monitoring()
            self.display_engagement_pub.publish(Bool(False))  # Hide engagement levels
            self.pause_engagement_detector()
            self.stop_website_blocker()  # Unblock websites during break
        elif self.pomodoro_state == 'paused':
            self.stop_engagement_monitoring()
        elif self.pomodoro_state == 'pomodoro_completed':
            self.stop_engagement_monitoring()
            self.display_engagement_pub.publish(Bool(False))
            self.handle_pomodoro_completion()  # Handle the end of the entire Pomodoro cycle
            self.stop_website_blocker()  # Ensure websites are unblocked after completion
        else:
            # Unknown state
            rospy.logwarn(f"Unknown pomodoro state: {self.pomodoro_state}")

    def check_engagement(self, event):
        if self.engagement_monitoring:
            current_time = rospy.get_time()
            self.engagement_levels = [(t, val) for t, val in self.engagement_levels if current_time - t <= 30]
            if self.engagement_levels:
                values = [val for t, val in self.engagement_levels]
                average_engagement = sum(values) / len(values)
                if not self.is_conversation_active:
                    rospy.loginfo(f"Average engagement over last 30 seconds: {average_engagement}")
                if average_engagement < 0.93:
                    current_time = time.time()
                    if not self.is_conversation_active and \
                       (self.last_conversation_time is None or (current_time - self.last_conversation_time) > self.cooldown_period):
                        if acquire_lock:
                            self.conversation_requested = True
                        else:
                            print("Conversation locked by another script.")
                    else:
                        if not self.is_conversation_active:
                            rospy.loginfo("Cannot start conversation: either already active or cooldown period has not passed.")
            else:
                if not self.is_conversation_active:
                    rospy.logwarn("No engagement levels collected in the last 30 seconds.")

    def run_conversation(self):
        self.is_conversation_active = True
        self.display_engagement_pub.publish(Bool(False))
        self.pomodoro_timer.pause()
        self.pause_engagement_detector()
        try:
            logging.disable(logging.CRITICAL)
            # Start the conversation
            distraction_tasks = start_conversation()
            if distraction_tasks:
                self.distraction_tasks.extend(distraction_tasks)
        except Exception as e:
            logging.disable(logging.NOTSET)
            rospy.logerr(f"Error during conversation: {e}")
        finally:
            logging.disable(logging.NOTSET)
            self.is_conversation_active = False
            self.last_conversation_time = time.time()
            self.display_engagement_pub.publish(Bool(True))
            self.pomodoro_timer.resume()
            release_lock_with_delay(100)
            print("Lock will be released in 2 minutes.")
            self.resume_engagement_detector()

    def handle_pomodoro_completion(self):
        if self.is_shutting_down:
            return  # Do not handle pomodoro completion during shutdown
        rospy.loginfo("Pomodoro cycle completed.")
        # Pause the engagement detector as the session is over
        self.pause_engagement_detector()
        if self.distraction_tasks:
            # Run post-Pomodoro conversation
            additional_tasks = post_pomodoro_conversation(self.distraction_tasks)
            if additional_tasks:
                self.distraction_tasks.extend(additional_tasks)
        else:
            self.pomodoro_timer.talk("Your Pomodoro session has ended. Great job!")

    def start_engagement_detector(self):
        package = 'engagement_detector'  # Replace with your package name
        launch_file = 'engagement_detector.launch'  # Replace with your launch file name
        command = ['roslaunch', package, launch_file]
        self.engagement_detector_process = subprocess.Popen(command, preexec_fn=os.setsid)
        rospy.loginfo("Started engagement detector node.")

    def stop_engagement_detector(self):
        if self.engagement_detector_process:
            os.killpg(os.getpgid(self.engagement_detector_process.pid), signal.SIGTERM)
            rospy.loginfo("Stopped engagement detector node.")

    def pause_engagement_detector(self):
        if self.engagement_detector_process:
            os.killpg(os.getpgid(self.engagement_detector_process.pid), signal.SIGSTOP)
            rospy.loginfo("Paused engagement detector node.")

    def resume_engagement_detector(self):
        if self.engagement_detector_process:
            os.killpg(os.getpgid(self.engagement_detector_process.pid), signal.SIGCONT)
            rospy.loginfo("Resumed engagement detector node.")

    # Website blocker control methods
    def start_website_blocker(self):
        rospy.loginfo("Blocking websites...")
        script_path = '/home/qtrobot/catkin_ws/src/mira/engagement_detector/engagement_prompt/website_blocker.py'
        command = ['sudo', '/usr/bin/python3', script_path, 'block']
        try:
            subprocess.run(command, check=True)
            rospy.loginfo("Websites are blocked.")
        except subprocess.CalledProcessError as e:
            rospy.logerr(f"Failed to block websites: {e}")

    def stop_website_blocker(self):
        rospy.loginfo("Unblocking websites...")
        script_path = '/home/qtrobot/catkin_ws/src/mira/engagement_detector/engagement_prompt/website_blocker.py'
        command = ['sudo', '/usr/bin/python3', script_path, 'unblock']
        try:
            subprocess.run(command, check=True)
            rospy.loginfo("Websites are unblocked.")
        except subprocess.CalledProcessError as e:
            rospy.logerr(f"Failed to unblock websites: {e}")

    def run(self):
        self.start_engagement_detector()
        rospy.loginfo("Waiting for engagement detector to start publishing...")
        # Wait indefinitely until the engagement detector starts
        while not self.engagement_detector_started and not rospy.is_shutdown():
            time.sleep(0.1)
        try:
            while not rospy.is_shutdown():
                time.sleep(1)
                if self.conversation_requested:
                    self.conversation_requested = False
                    self.run_conversation()
        except KeyboardInterrupt:
            pass
        # Stop the engagement detector when the application is shutting down
        self.stop_engagement_detector()
        # Ensure websites are unblocked when the program exits
        self.stop_website_blocker()

if __name__ == "__main__":
    rospy.init_node('main_app_node')
    app = MainApp()
    app.run()

