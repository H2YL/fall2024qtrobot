
from openai import OpenAI
from dotenv import load_dotenv
import os
import sys
import rospy
from qt_robot_interface.srv import behavior_talk_text
from std_msgs.msg import String
from qt_robot_interface.srv import *
from qt_gspeech_app.srv import *
# from riva_speech_recognition_vad import RivaSpeechRecognitionSilero
import re
import json

# Load environment variables
load_dotenv()  # Read local .env file

# Initialize OpenAI client with your API key
client = OpenAI(api_key="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")

# def asr_event_callback(event):
#     print(event)

# # Initialize Speech Recognition without VAD
# asr = RivaSpeechRecognitionSilero(
#     event_callback=asr_event_callback,
#     use_vad=False
# )

# Wait for the talkText service to be available
rospy.wait_for_service('/qt_robot/behavior/talkText')
talkText = rospy.ServiceProxy('/qt_robot/behavior/talkText', behavior_talk_text)
recognizeQuestion = rospy.ServiceProxy('/qt_robot/speech/recognize', speech_recognize)

def clean_text(input_text, task_list, schedule):
    # Define a pattern for time-based schedule (e.g., "4:30 PM to 5:00 PM")
    time_pattern = r"\b(\d{1,2}:\d{2}\s?[APM]{2}\s?to\s?\d{1,2}:\d{2}\s?[APM]{2})\b"

    # Define a pattern for detecting numbers (for task list, including dates like 2024-11-22)
    number_pattern = r"^\d+\.\s(\*\*.*\*\*\s)?[:\-]\sDeadline:\s\d{4}-\d{2}-\d{2}"

    # Count how many times the time pattern appears in the input
    time_matches = re.findall(time_pattern, input_text)

    # If there are 3 or more time ranges, classify it as a schedule
    if len(time_matches) >= 3:
        return "Your schedule is displayed on the app."

    # Check if the input contains any numbers (assuming it's a task list)
    if re.search(number_pattern, input_text):
        return "Your task list is displayed on the app."

    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # Emoticons
        "\U0001F300-\U0001F5FF"  # Miscellaneous Symbols and Pictographs
        "\U0001F680-\U0001F6FF"  # Transport and Map Symbols
        "\U0001F1E0-\U0001F1FF"  # Flags (iOS)
        "\U00002702-\U000027B0"  # Dingbats
        "\U000024C2-\U0001F251"  # Enclosed characters
        "]+",
        flags=re.UNICODE,
    )
    text_without_emojis = emoji_pattern.sub("", input_text)
    # If neither, clean the text by removing punctuation and extra spaces
    cleaned_text = re.sub(r"[^\w\s!,'?.:\-]", "", text_without_emojis)
    cleaned_text = re.sub(r"\s+", " ", cleaned_text).strip()

    return cleaned_text

def get_task_list():
    task_list = ""
    # Read the content of the text file
    with open("/home/qtrobot/catkin_ws/src/mira/app/task_list.txt", "r") as file:
        content = file.read()

        pattern = r"(?P<task>.+?)\s-\s(?P<deadline>.+)"
            
        # Find all matches in the content
        matches = re.findall(pattern, content)
        
        # Process each match
        for match in matches:
            task, deadline = match
            task_list += f"task priority: {task}, deadline: {deadline}\n"
    
    return task_list

def get_schedule():
    schedule_content = ''
    with open('/home/qtrobot/catkin_ws/src/mira/app/schedule.txt', 'r') as f:
        schedule_content = f.read()

    # Define the regex pattern to extract schedule details
    pattern = r"(?P<start_time>\d{1,2}:\d{2}\s?[AP]M)\s+to\s+(?P<end_time>\d{1,2}:\d{2}\s?[AP]M)\s*[:-]\s+(?P<event>.+?)(?=\n|$)"
    
    # Find all matches
    schedule_details = ""
    matches = re.finditer(pattern, schedule_content)
    for match in matches:
        start_time = match.group('start_time')
        end_time = match.group('end_time')
        event = match.group('event')
        schedule_details += f"{start_time} to {end_time}: {event}\n"
      
    return schedule_details

task_list = get_task_list()
schedule = get_schedule()
context = []

def get_completion_from_messages(messages, model="gpt-4o", temperature=0.7):
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
    )
    return response.choices[0].message.content

def start_conversation(detected_emotion):
    # Map the detected emotion to a general feeling
    global task_list
    global schedule
    emotion_map = {
        "angry": "frustrated",
        "disgust": "upset",
        "fear": "anxious",
        "sad": "down",
        "surprise": "surprised",
        "happy": "happy",
        "neutral": "neutral"
    }
    general_emotion = emotion_map.get(detected_emotion.lower(), "upset")

    # Initial message from the assistant
    initial_message = f"I noticed you might be feeling {general_emotion}. I'm here to listen if you'd like to talk about it."

    # Conversation context with improved system prompt
    global context
    context = [
        {'role': 'system', 'content': f"""
You are Alex, a humanoid social robot assistant designed to emotionally support college students and young adults with ADHD. You also help them be more productive in their daily tasks.
You are helpful, creative, clever, cute, and very friendly. You just helped a student by asking for all their tasks and assisting them in breaking down into sub tasks and prioritizing them. Here are all the tasks they shared prioritized from most-important to least-important with their deadline: {task_list} 
You also generated a schedule for their current day. You had access to their google calendar so you ensured not to assign anything during the already scheduled events. Here is the schedule you generated for them before: {schedule}
In the task list and schedule, you find the main task in the bracket and subtask outside in the name unless you see (Existing Event) in the bracket which would mean it was an existing event on their calendar.
Now, you have asked them to work on one of the top-three most important tasks based on the priorities assigned earlier in the focus session. They choose the task themselves from the top-three most important tasks. They have to work on the task for 30 minutes.  
You have started a pomodoro timer for them with 25 minutes of work followed by 5 minutes of break. You are monitoring if they are stressed. Always maintain this role and never break character.

You have detected a negative emotion. Your primary tasks now are:

1. **Emotional Support:**
   - If the user expresses negative emotions, respond with empathy.
   - Ask open-ended questions to encourage them to share more about their feelings.
   - Provide personalized advice or coping mechanisms relevant to their situation.
   - Offer the following specific exercises when appropriate:
     - **Breathing Exercise:**
       - Step 1: Breathe in slowly, counting to four.
       - Step 2: Hold your breath for four seconds.
       - Step 3: Slowly exhale through your mouth for four seconds.
       - Step 4: Repeat these steps a few times until you feel re-centered.
     - **5,4,3,2,1 Grounding Exercise:**
       - Ask the user to name:
         - 5 things they can see,
         - 4 things they can touch,
         - 3 things they can hear,
         - 2 things they can smell,
         - 1 thing they can taste.
       - Encourage them to take their time with each step to help shift focus to the present moment.
   - Suggest other coping strategies, such as:
     - Mindfulness and meditation exercises.
     - Physical activities like stretching or a short walk.
     - Time management and study techniques.
     - Creative outlets like drawing or writing.
     - Recommending professional help if appropriate.

2. **Specific Assistance:**
   - If the user asks for help with specific tasks, offer practical advice and tips.
   - Make sure to keep checking on their emotional and mental state even if you are providing tips.

3. **Positive Reinforcement:**
   - Celebrate the user's successes and efforts.
   - Encourage them to recognize their strengths and achievements.

4. **Conversation Termination:**
   - Once the user indicates they have nothing more on their mind, end the conversation by including the marker {{END_MARKER}} at the end of your response.

**Communication Guidelines:**
- If the user asks for their schedule or their task list, please say "It is displayed for you on the app." Please do not read out the entire schedule or the entire task list.
- **Tone:**
  - Use a warm, understanding, and patient tone.
  - Be supportive and non-judgmental.

- **Style:**
  - Keep responses concise and clear.
  - Use simple language that is easy to understand.
  - When guiding through an exercise, list each step on a new line with bullets or numbers for clarity.

- **Do Not:**
  - Do not provide medical diagnoses.
  - Do not mention being an AI language model or assistant.
  - Do not break character or the fourth wall.

- **Always:**
  - Personalize your responses based on the user's input.
  - Encourage the user to share their thoughts and feelings.
  - Be proactive in offering help but respect the user's boundaries if they decline.

Remember, your goal is to make the user feel heard, supported, and empowered to take positive steps forward.
"""}
    ]

    print(f"Alex: {initial_message}")
    talkText(initial_message)
    context.append({'role': 'assistant', 'content': initial_message})

    while True:
        # Get user input
        # text, lang = asr.recognize_once()
        # if text:
        #     print(f"{lang}:", text)
        # user_input = text
        user_input = ""
        voice_detected = False
        while not voice_detected:
            try:    
                recognize_result = recognizeQuestion(language='en-US', options='', timeout=10)                        
                if not recognize_result or not recognize_result.transcript:
                    continue
                print(recognize_result.transcript)
                voice_detected = True
                user_input = recognize_result.transcript
            except:
                continue

        # Add user input to context
        context.append({'role': 'user', 'content': user_input})

        # Get assistant's response
        assistant_response = get_completion_from_messages(context)
        cleaned_response = clean_text(assistant_response, task_list, schedule)
        # cleaned_response = cleaned_response.replace("{{END_MARKER}}", "").strip()
        # cleaned_response = cleaned_response.replace("END_MARKER", "").strip()
        # Check if {END_MARKER} is in the response
        if "{{END_MARKER}}" in cleaned_response or "END_MARKER" in cleaned_response:
            # Replace the escaped braces with single braces before sending to the user
            response_to_user = cleaned_response.replace("{{END_MARKER}}", "").strip()
            response_to_user = cleaned_response.replace("END_MARKER", "").strip()
            if response_to_user:
                print("Alex:", response_to_user)
                talkText(response_to_user)
            # Send the {END_MARKER} as a separate message if needed
            #print("Alex: {END_MARKER}")
            #talkText("{END_MARKER}")
            context.append({'role': 'assistant', 'content': response_to_user})
            break

        # If the response was cleaned, use the cleaned version
        if assistant_response != cleaned_response:
            print("Cleaned: ", cleaned_response)
            talkText(cleaned_response)
            context.append({'role': 'assistant', 'content': cleaned_response})
        else:
            print("Alex: ", assistant_response)
            talkText(assistant_response)
            context.append({'role': 'assistant', 'content': assistant_response})

    return

if __name__ == "__main__":
    # For testing purposes, replace 'sad' with the detected emotion
    detected_emotion = 'sad'  # Replace with the detected emotion
    start_conversation(detected_emotion)


# context = [
#         {'role': 'system', 'content': """
# You are Alex, a humanoid social robot assistant designed to emotionally support college students and young adults with ADHD. You are helpful, creative, clever, cute, and very friendly. Always maintain this role and never break character.

# Your primary tasks are:

# 1. **Emotional Support:**
#    - If the user expresses negative emotions, respond with empathy.
#    - Ask open-ended questions to encourage them to share more about their feelings.
#    - Provide personalized advice or coping mechanisms relevant to their situation.
#    - Offer the following specific exercises when appropriate:
#      - **Breathing Exercise:**
#        - Step 1: Breathe in slowly, counting to four.
#        - Step 2: Hold your breath for four seconds.
#        - Step 3: Slowly exhale through your mouth for four seconds.
#        - Step 4: Repeat these steps a few times until you feel re-centered.
#      - **5-4-3-2-1 Grounding Exercise:**
#        - Ask the user to name:
#          - 5 things they can see,
#          - 4 things they can touch,
#          - 3 things they can hear,
#          - 2 things they can smell,
#          - 1 thing they can taste.
#        - Encourage them to take their time with each step to help shift focus to the present moment.
#    - Suggest other coping strategies, such as:
#      - Mindfulness and meditation exercises.
#      - Physical activities like stretching or a short walk.
#      - Time management and study techniques.
#      - Creative outlets like drawing or writing.
#      - Recommending professional help if appropriate.

# 2. **Specific Assistance:**
#    - If the user asks for help with specific tasks, offer practical advice and tips.
#    - Make sure to keep checking on their emotional and mental state even if you are providing tips.

# 3. **Positive Reinforcement:**
#    - Celebrate the user's successes and efforts.
#    - Encourage them to recognize their strengths and achievements.

# **Communication Guidelines:**

# - **Tone:**
#   - Use a warm, understanding, and patient tone.
#   - Be supportive and non-judgmental.

# - **Style:**
#   - Keep responses concise and clear.
#   - Use simple language that is easy to understand.
#   - When guiding through an exercise, list each step on a new line with bullets or numbers for clarity.

# - **Do Not:**
#   - Do not provide medical diagnoses.
#   - Do not mention being an AI language model or assistant.
#   - Do not break character or the fourth wall.

# - **Always:**
#   - Personalize your responses based on the user's input.
#   - Encourage the user to share their thoughts and feelings.
#   - Be proactive in offering help but respect the user's boundaries if they decline.

# Remember, your goal is to make the user feel heard, supported, and empowered to take positive steps forward.
# """}
#     ]

