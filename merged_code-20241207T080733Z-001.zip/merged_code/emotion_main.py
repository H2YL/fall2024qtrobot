#!/usr/bin/env python3
from working_prompt import start_conversation
import rospy
import time
from emotion_detection_array import EmotionDetector

from qt_robot_interface.srv import behavior_talk_text
from std_msgs.msg import String
from frame_client import FrameClient
import threading
import os
import fcntl

# LOCK_FILE = "/tmp/conversation.lock"
# # if os.path.exists(LOCK_FILE):
# #    os.remove(LOCK_FILE)
# def acquire_lock():
#     if os.path.exists(LOCK_FILE):
#         return False
#     with open(LOCK_FILE, "w") as f:
#         f.write("locked by emotion detection.\n")
#     return True

# def release_lock():
#     if os.path.exists(LOCK_FILE):
#         os.remove(LOCK_FILE)

# def release_lock_with_delay(delay_seconds):
#     def delay_release():
#         with open(LOCK_FILE, "a") as f:
#             f.write("Releasing emotion lock in 2 minutes.")
#         time.sleep(delay_seconds)
#         release_lock()
#         print("Lock released.")
#     threading.Thread(target=delay_release, daemon=True).start()
LOCK_FILE = "/tmp/conversation.lock"

# Try to acquire the lock
def acquire_lock():
    try:
        if os.path.exists(LOCK_FILE):
            return False
        else:
            lock_file = open(LOCK_FILE, "w+")
            fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_file.write("locked by emotion detection.\n")
            lock_file.flush()
            lock_file.close()
            # If successful, return the lock file object for future use
            return True
    except IOError:
        # If the lock is already held, return None
        return False
    except:
        print(f"An error occurred: {e}")
        return False

# Release the lock
def release_lock():
    try:
        lock_file = open(LOCK_FILE, "r+")
       
        fcntl.flock(lock_file, fcntl.LOCK_UN)  # Unlock the file
        lock_file.close()  # Close the lock file
        print("Lock released.")
        os.remove(LOCK_FILE)
    except Exception as e:
        print(f"Error releasing lock: {e}")

# Release the lock with a delay in a separate thread
def release_lock_with_delay(delay_seconds):
    def delay_release():
        lock_file = open(LOCK_FILE, "a")
        lock_file.write("Releasing emotion lock in 2 minutes.")
        lock_file.flush()
        lock_file.close()
        time.sleep(delay_seconds)
        release_lock()
    
    threading.Thread(target=delay_release, daemon=True).start()

class EmotionMonitor:
    def __init__(self):
        print("Starting")
        rospy.init_node('emotion_monitor_node')
        self.emotion_detector = EmotionDetector()
        self.talkText = rospy.ServiceProxy('/qt_robot/behavior/talkText', behavior_talk_text)
        self.emotion_publisher = rospy.Publisher('/qt_robot/emotion/show', String, queue_size=10)

        # Conversation management
        self.is_conversation_active = False
        self.last_conversation_time = 0
        self.conversation_cooldown = 120  # Cooldown period in seconds

        # Modify the analysis interval and history size
        self.analysis_interval = 30  # Analyze emotions every 30 seconds
        self.emotion_detector.max_history_size = int(self.analysis_interval / self.emotion_detector.detection_interval_sec)

        self.last_check_time = time.time()

    def run(self):
        try:
            while not rospy.is_shutdown():
                frame, emotion = self.emotion_detector.detect_emotion()
                if emotion != None:
                    print("Emotion: ", emotion)
		
                # Display the frame with emotion label
                # self.emotion_detector.display_frame(frame, emotion)

                # Analyze emotions every analysis_interval
                if time.time() - self.last_check_time >= self.analysis_interval:
                    self.check_emotion_threshold()
                    self.last_check_time = time.time()

                rospy.sleep(0.1)
        except KeyboardInterrupt:
            pass
        finally:
            self.emotion_detector.release_resources()

    def is_negative_emotion(self, emotion):
        negative_emotions = ['angry', 'disgust', 'fear', 'sad', 'surprise']  # Define negative emotions
        return emotion.lower() in negative_emotions

    def check_emotion_threshold(self):
        if not self.emotion_detector.emotion_history:
            return

        negative_count = sum(1 for emotion in self.emotion_detector.emotion_history if self.is_negative_emotion(emotion))
        total_count = len(self.emotion_detector.emotion_history)
        negative_percentage = (negative_count / total_count) * 100

        # Set a threshold percentage for negative emotions
        threshold = 60  # For example, 40%

        # Clear the emotion history for the next interval
        self.emotion_detector.emotion_history.clear()

        if negative_percentage >= threshold and not self.is_conversation_active:
            self.handle_negative_emotion_detected()

    def handle_negative_emotion_detected(self, emotion=None):
        current_time = time.time()
        if self.is_conversation_active:
            return
        if current_time - self.last_conversation_time < self.conversation_cooldown:
            return

        self.is_conversation_active = True

        if not emotion:
            # Use the most recent negative emotion from history
            emotion = next((e for e in reversed(self.emotion_detector.emotion_history) if self.is_negative_emotion(e)), "sad")

        rospy.loginfo(f"Detected negative emotion: {emotion}")
        if not acquire_lock():
            print("Conversation locked by another script.")
        else:    
            user_feels_better = start_conversation(emotion)
            if user_feels_better:
                rospy.loginfo("User feels better now.")
            else:
                rospy.loginfo("Conversation ended without resolution.")
            release_lock_with_delay(100)
            print("Lock will be released in 2 minutes.")
            self.last_conversation_time = current_time
        self.is_conversation_active = False

if __name__ == "__main__":
    monitor = EmotionMonitor()
    monitor.run()
